# Keep WebView JavascriptInterface methods
-keepclassmembers class com.myexcel.app.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
