# My Excel Zamshed

**Package:** `com.myexcel.app`  
**App Name:** My Excel Zamshed

Android WebView Spreadsheet Application + Cloud APK Build Workflow.

## Option 1: Build APK in 2 Minutes on GitHub (No PC / No Android Studio Needed)
1. Create a new repository on GitHub (e.g. `MyExcelZamshed`).
2. Upload all files from this ZIP to that repository.
3. Open the **Actions** tab on GitHub → click **Build Android APK** → **Run workflow**.
4. Once finished (~90 seconds), download **MyExcelZamshed-debug-apk** (`app-debug.apk`) from the workflow Artifacts and install it on your Android phone!

## Option 2: Build Locally in Android Studio
1. Open this folder (`MyExcelZamshed`) in Android Studio.
2. Wait for Gradle Sync to finish.
3. Click **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Locate `app/build/outputs/apk/debug/app-debug.apk`.
